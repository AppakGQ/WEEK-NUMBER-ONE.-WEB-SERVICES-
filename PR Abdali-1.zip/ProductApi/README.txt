ProductApi — готовый ASP.NET Core Web API

Требования:
- .NET 8 SDK

Запуск:
1. Распакуйте ZIP.
2. Откройте папку ProductApi в Visual Studio / Rider / VS Code.
3. Выполните:
   dotnet restore
   dotnet run

API:
GET  /api/products
GET  /api/products/1
POST /api/products

Пример POST JSON:
{
  "name": "Клавиатура",
  "description": "Механическая клавиатура",
  "price": 29990,
  "category": "Аксессуары",
  "stockQuantity": 10
}
