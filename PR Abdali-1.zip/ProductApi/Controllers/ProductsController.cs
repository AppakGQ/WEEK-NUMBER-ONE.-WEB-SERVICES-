using Microsoft.AspNetCore.Mvc;
using ProductApi.Models;

namespace ProductApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ProductsController : ControllerBase
{
    private static readonly List<Product> Products = new()
    {
        new Product
        {
            Id = 1,
            Name = "Ноутбук ASUS VivoBook",
            Description = "Ноутбук для учебы и работы",
            Price = 349990,
            Category = "Ноутбуки",
            StockQuantity = 12
        },
        new Product
        {
            Id = 2,
            Name = "Мышь Logitech M185",
            Description = "Беспроводная компьютерная мышь",
            Price = 7990,
            Category = "Аксессуары",
            StockQuantity = 25
        }
    };

    [HttpGet]
    public ActionResult<IEnumerable<Product>> GetAll()
    {
        return Ok(Products);
    }

    [HttpGet("{id}")]
    public ActionResult<Product> GetById(int id)
    {
        var product = Products.FirstOrDefault(p => p.Id == id);

        if (product is null)
            return NotFound();

        return Ok(product);
    }

    [HttpPost]
    public ActionResult<Product> Create(Product product)
    {
        product.Id = Products.Count == 0
            ? 1
            : Products.Max(p => p.Id) + 1;

        Products.Add(product);

        return CreatedAtAction(
            nameof(GetById),
            new { id = product.Id },
            product);
    }
}
